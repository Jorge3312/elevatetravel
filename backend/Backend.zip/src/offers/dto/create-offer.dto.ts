import { IsNotEmpty, IsString, MaxLength, IsUrl, IsBoolean, IsOptional, IsDateString } from 'class-validator';

export class CreateOfferDto {
  @IsNotEmpty()
  @IsString()
  @MaxLength(200)
  title: string;

  @IsNotEmpty()
  @IsString()
  description: string;

  @IsNotEmpty()
  @IsUrl()
  @MaxLength(1000)
  photo_url: string;

  @IsNotEmpty()
  @IsDateString()
  valid_until: string;

  @IsBoolean()
  @IsOptional()
  is_active?: boolean = true;
}
