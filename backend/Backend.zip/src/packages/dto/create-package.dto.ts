import { IsNotEmpty, IsString, MaxLength, IsUrl, IsBoolean, IsOptional, IsNumber, Min } from 'class-validator';

export class CreatePackageDto {
  @IsNotEmpty()
  @IsString()
  destination_id: string;

  @IsNotEmpty()
  @IsString()
  @MaxLength(200)
  title: string;

  @IsNotEmpty()
  @IsString()
  description: string;

  @IsNotEmpty()
  @IsNumber()
  @Min(0)
  price: number;

  @IsNotEmpty()
  @IsUrl()
  @MaxLength(1000)
  photo_url: string;

  @IsNotEmpty()
  @IsString()
  itinerary: string;

  @IsNotEmpty()
  @IsString()
  includes: string;

  @IsNotEmpty()
  @IsString()
  excludes: string;

  @IsBoolean()
  @IsOptional()
  is_active?: boolean = true;
}
