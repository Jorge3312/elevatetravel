import { IsNotEmpty, IsString, MaxLength, IsUrl, IsBoolean, IsOptional } from 'class-validator';

export class CreateVisaDto {
  @IsNotEmpty()
  @IsString()
  @MaxLength(100)
  country: string;

  @IsNotEmpty()
  @IsString()
  requirements: string;

  @IsNotEmpty()
  @IsUrl()
  @MaxLength(1000)
  photo_url: string;

  @IsBoolean()
  @IsOptional()
  is_active?: boolean = true;
}
