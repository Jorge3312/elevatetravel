import { IsNotEmpty, IsString, MaxLength, IsUrl, IsBoolean, IsOptional, IsNumber, IsDateString } from 'class-validator';

export class CreateEventDto {
  @IsNotEmpty()
  @IsString()
  destination_id: string;

  @IsNotEmpty()
  @IsString()
  @MaxLength(200)
  title: string;

  @IsNotEmpty()
  @IsString()
  description: string;

  @IsNotEmpty()
  @IsUrl()
  @MaxLength(1000)
  photo_url: string;

  @IsNotEmpty()
  @IsDateString()
  date: string;

  @IsOptional()
  @IsString()
  @MaxLength(100)
  time?: string;

  @IsNotEmpty()
  @IsString()
  @MaxLength(255)
  location: string;

  @IsBoolean()
  @IsOptional()
  is_active?: boolean = true;
}
