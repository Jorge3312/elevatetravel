import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators, FormsModule } from '@angular/forms';
import { EventsService } from '../../../core/services/events';
import { DestinationsService } from '../../../core/services/destinations';
import { TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import { DialogModule } from 'primeng/dialog';
import { InputTextModule } from 'primeng/inputtext';
import { ToggleSwitchModule } from 'primeng/toggleswitch';
import { DatePickerModule } from 'primeng/datepicker';
import { SelectModule } from 'primeng/select';
import { TextareaModule } from 'primeng/textarea';

@Component({
  selector: 'app-events',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, TableModule, ButtonModule, DialogModule, InputTextModule, ToggleSwitchModule, DatePickerModule, SelectModule, TextareaModule],
  template: `
    <div class="space-y-6">
      <div class="flex justify-between items-center">
        <div>
          <h1 class="text-2xl font-light tracking-widest uppercase">Eventos</h1>
          <p class="text-white/50 text-sm mt-1">Gestiona eventos exclusivos por destino.</p>
        </div>
        <button pButton icon="pi pi-plus" label="Nuevo Evento" class="p-button-outlined p-button-sm" (click)="showDialog()"></button>
      </div>

      <div class="glass-panel rounded-xl overflow-hidden">
        <p-table [value]="events" [paginator]="true" [rows]="10" responsiveLayout="scroll" styleClass="p-datatable-sm p-datatable-dark">
          <ng-template pTemplate="header">
            <tr>
              <th>Nombre</th>
              <th>Fecha</th>
              <th>Destino</th>
              <th>Precio</th>
              <th>Estado</th>
              <th class="text-right">Acciones</th>
            </tr>
          </ng-template>
          <ng-template pTemplate="body" let-evt>
            <tr>
              <td class="font-medium">{{ evt.name }}</td>
              <td>{{ evt.event_date | date }}</td>
              <td>{{ evt.destination?.city }}</td>
              <td>{{ evt.base_price | currency }}</td>
              <td>
                <p-toggleswitch [ngModel]="evt.is_active" (onChange)="toggleStatus(evt)"></p-toggleswitch>
              </td>
              <td class="text-right space-x-2">
                <button pButton icon="pi pi-pencil" class="p-button-rounded p-button-text p-button-sm" (click)="editEvent(evt)"></button>
                <button pButton icon="pi pi-trash" class="p-button-rounded p-button-text p-button-danger p-button-sm" (click)="deleteEvent(evt.id)"></button>
              </td>
            </tr>
          </ng-template>
        </p-table>
      </div>

      <p-dialog [(visible)]="displayDialog" [header]="isEditing ? 'Editar Evento' : 'Nuevo Evento'" [modal]="true" [style]="{width: '500px'}" styleClass="p-fluid">
        <form [formGroup]="form" (ngSubmit)="saveEvent()" class="space-y-4 mt-4">
          <div class="field">
            <label class="text-sm text-white/70 block mb-2">Nombre del Evento</label>
            <input pInputText formControlName="name" class="w-full bg-black/50 border-white/10" />
          </div>
          <div class="field">
            <label class="text-sm text-white/70 block mb-2">Destino</label>
            <p-select [options]="destinations" formControlName="destination_id" optionLabel="city" optionValue="id" placeholder="Seleccionar Destino" styleClass="w-full"></p-select>
          </div>
          <div class="field">
            <label class="text-sm text-white/70 block mb-2">Fecha del Evento</label>
            <p-datepicker formControlName="event_date" [showIcon]="true" appendTo="body" styleClass="w-full"></p-datepicker>
          </div>
          <div class="field">
            <label class="text-sm text-white/70 block mb-2">Descripción</label>
            <textarea pTextarea formControlName="description" rows="3" class="w-full bg-black/50 border-white/10"></textarea>
          </div>
          <div class="field">
            <label class="text-sm text-white/70 block mb-2">Precio Base ($)</label>
            <input pInputText type="number" formControlName="base_price" class="w-full bg-black/50 border-white/10" />
          </div>
          <div class="field">
            <label class="text-sm text-white/70 block mb-2">URL de Imagen</label>
            <input pInputText formControlName="photo_url" class="w-full bg-black/50 border-white/10" />
          </div>
          <div class="field flex items-center justify-between pt-2">
            <label class="text-sm text-white/70">Activo</label>
            <p-toggleswitch formControlName="is_active"></p-toggleswitch>
          </div>
        </form>
        <ng-template pTemplate="footer">
          <button pButton label="Cancelar" icon="pi pi-times" class="p-button-text" (click)="displayDialog = false"></button>
          <button pButton label="Guardar" icon="pi pi-check" class="p-button-outlined" [disabled]="form.invalid" (click)="saveEvent()"></button>
        </ng-template>
      </p-dialog>
    </div>
  `
})
export class Events implements OnInit {
  private eventsService = inject(EventsService);
  private destService = inject(DestinationsService);
  private fb = inject(FormBuilder);

  events: any[] = [];
  destinations: any[] = [];
  displayDialog = false;
  isEditing = false;
  currentId: string | null = null;

  form: FormGroup = this.fb.group({
    destination_id: ['', Validators.required],
    name: ['', Validators.required],
    description: [''],
    event_date: [null, Validators.required],
    base_price: [0, Validators.required],
    photo_url: [''],
    is_active: [true]
  });

  ngOnInit() {
    this.loadEvents();
    this.destService.getAdminDestinations().subscribe(data => this.destinations = data);
  }

  loadEvents() {
    this.eventsService.getAdminEvents().subscribe({
      next: (data) => this.events = data,
      error: (err) => console.error(err)
    });
  }

  showDialog() {
    this.isEditing = false;
    this.currentId = null;
    this.form.reset({ is_active: true, base_price: 0 });
    this.displayDialog = true;
  }

  editEvent(evt: any) {
    this.isEditing = true;
    this.currentId = evt.id;
    this.form.patchValue({
      ...evt,
      destination_id: evt.destination?.id,
      event_date: new Date(evt.event_date)
    });
    this.displayDialog = true;
  }

  saveEvent() {
    if (this.form.invalid) return;
    const req = this.isEditing && this.currentId
      ? this.eventsService.update(this.currentId, this.form.value)
      : this.eventsService.create(this.form.value);

    req.subscribe({
      next: () => {
        this.displayDialog = false;
        this.loadEvents();
      },
      error: (err) => console.error(err)
    });
  }

  deleteEvent(id: string) {
    if (confirm('¿Eliminar evento?')) {
      this.eventsService.delete(id).subscribe(() => this.loadEvents());
    }
  }

  toggleStatus(evt: any) {
    this.eventsService.toggleStatus(evt.id).subscribe({
      next: () => evt.is_active = !evt.is_active,
      error: () => {}
    });
  }
}
