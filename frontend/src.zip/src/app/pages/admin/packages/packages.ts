import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators, FormsModule } from '@angular/forms';
import { PackagesService } from '../../../core/services/packages';
import { DestinationsService } from '../../../core/services/destinations';
import { TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import { DialogModule } from 'primeng/dialog';
import { InputTextModule } from 'primeng/inputtext';
import { ToggleSwitchModule } from 'primeng/toggleswitch';
import { SelectModule } from 'primeng/select';
import { TextareaModule } from 'primeng/textarea';

@Component({
  selector: 'app-packages',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, TableModule, ButtonModule, DialogModule, InputTextModule, ToggleSwitchModule, SelectModule, TextareaModule],
  template: `
    <div class="space-y-6">
      <div class="flex justify-between items-center">
        <div>
          <h1 class="text-2xl font-light tracking-widest uppercase">Paquetes</h1>
          <p class="text-white/50 text-sm mt-1">Gestiona los paquetes de viaje.</p>
        </div>
        <button pButton icon="pi pi-plus" label="Nuevo Paquete" class="p-button-outlined p-button-sm" (click)="showDialog()"></button>
      </div>

      <div class="glass-panel rounded-xl overflow-hidden">
        <p-table [value]="packages" [paginator]="true" [rows]="10" responsiveLayout="scroll" styleClass="p-datatable-sm p-datatable-dark">
          <ng-template pTemplate="header">
            <tr>
              <th>Nombre</th>
              <th>Destino</th>
              <th>Días</th>
              <th>Noches</th>
              <th>Precio</th>
              <th>Estado</th>
              <th class="text-right">Acciones</th>
            </tr>
          </ng-template>
          <ng-template pTemplate="body" let-pkg>
            <tr>
              <td class="font-medium">{{ pkg.name }}</td>
              <td>{{ pkg.destination?.city }}</td>
              <td>{{ pkg.days }}</td>
              <td>{{ pkg.nights }}</td>
              <td>{{ pkg.base_price | currency }}</td>
              <td>
                <p-toggleswitch [ngModel]="pkg.is_active" (onChange)="toggleStatus(pkg)"></p-toggleswitch>
              </td>
              <td class="text-right space-x-2">
                <button pButton icon="pi pi-pencil" class="p-button-rounded p-button-text p-button-sm" (click)="editPackage(pkg)"></button>
                <button pButton icon="pi pi-trash" class="p-button-rounded p-button-text p-button-danger p-button-sm" (click)="deletePackage(pkg.id)"></button>
              </td>
            </tr>
          </ng-template>
        </p-table>
      </div>

      <p-dialog [(visible)]="displayDialog" [header]="isEditing ? 'Editar Paquete' : 'Nuevo Paquete'" [modal]="true" [style]="{width: '500px'}" styleClass="p-fluid">
        <form [formGroup]="form" (ngSubmit)="savePackage()" class="space-y-4 mt-4">
          <div class="field">
            <label class="text-sm text-white/70 block mb-2">Nombre del Paquete</label>
            <input pInputText formControlName="name" class="w-full bg-black/50 border-white/10" />
          </div>
          <div class="field">
            <label class="text-sm text-white/70 block mb-2">Destino</label>
            <p-select [options]="destinations" formControlName="destination_id" optionLabel="city" optionValue="id" placeholder="Seleccionar Destino" styleClass="w-full"></p-select>
          </div>
          <div class="field">
            <label class="text-sm text-white/70 block mb-2">Descripción</label>
            <textarea pTextarea formControlName="description" rows="3" class="w-full bg-black/50 border-white/10"></textarea>
          </div>
          <div class="grid grid-cols-2 gap-4">
            <div class="field">
              <label class="text-sm text-white/70 block mb-2">Días</label>
              <input pInputText type="number" formControlName="days" class="w-full bg-black/50 border-white/10" />
            </div>
            <div class="field">
              <label class="text-sm text-white/70 block mb-2">Noches</label>
              <input pInputText type="number" formControlName="nights" class="w-full bg-black/50 border-white/10" />
            </div>
          </div>
          <div class="field">
            <label class="text-sm text-white/70 block mb-2">Precio Base ($)</label>
            <input pInputText type="number" formControlName="base_price" class="w-full bg-black/50 border-white/10" />
          </div>
          <div class="field flex items-center justify-between pt-2">
            <label class="text-sm text-white/70">Activo</label>
            <p-toggleswitch formControlName="is_active"></p-toggleswitch>
          </div>
        </form>
        <ng-template pTemplate="footer">
          <button pButton label="Cancelar" icon="pi pi-times" class="p-button-text" (click)="displayDialog = false"></button>
          <button pButton label="Guardar" icon="pi pi-check" class="p-button-outlined" [disabled]="form.invalid" (click)="savePackage()"></button>
        </ng-template>
      </p-dialog>
    </div>
  `
})
export class Packages implements OnInit {
  private packagesService = inject(PackagesService);
  private destService = inject(DestinationsService);
  private fb = inject(FormBuilder);

  packages: any[] = [];
  destinations: any[] = [];
  displayDialog = false;
  isEditing = false;
  currentId: string | null = null;

  form: FormGroup = this.fb.group({
    destination_id: ['', Validators.required],
    name: ['', Validators.required],
    description: [''],
    days: [0, Validators.required],
    nights: [0, Validators.required],
    base_price: [0, Validators.required],
    is_active: [true]
  });

  ngOnInit() {
    this.loadPackages();
    this.destService.getAdminDestinations().subscribe(data => this.destinations = data);
  }

  loadPackages() {
    this.packagesService.getAdminPackages().subscribe({
      next: (data) => this.packages = data,
      error: (err) => console.error(err)
    });
  }

  showDialog() {
    this.isEditing = false;
    this.currentId = null;
    this.form.reset({ is_active: true, base_price: 0, days: 0, nights: 0 });
    this.displayDialog = true;
  }

  editPackage(pkg: any) {
    this.isEditing = true;
    this.currentId = pkg.id;
    this.form.patchValue({
      ...pkg,
      destination_id: pkg.destination?.id
    });
    this.displayDialog = true;
  }

  savePackage() {
    if (this.form.invalid) return;
    const req = this.isEditing && this.currentId
      ? this.packagesService.update(this.currentId, this.form.value)
      : this.packagesService.create(this.form.value);

    req.subscribe({
      next: () => {
        this.displayDialog = false;
        this.loadPackages();
      },
      error: (err) => console.error(err)
    });
  }

  deletePackage(id: string) {
    if (confirm('¿Eliminar paquete?')) {
      this.packagesService.delete(id).subscribe(() => this.loadPackages());
    }
  }

  toggleStatus(pkg: any) {
    this.packagesService.toggleStatus(pkg.id).subscribe({
      next: () => pkg.is_active = !pkg.is_active,
      error: () => {}
    });
  }
}
