import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DestinationsService } from '../../../core/services/destinations';
import { EventsService } from '../../../core/services/events';
import { PackagesService } from '../../../core/services/packages';
import { OffersService } from '../../../core/services/offers';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="space-y-6">
      <div class="flex justify-between items-center">
        <div>
          <h1 class="text-2xl font-light tracking-widest uppercase">Dashboard</h1>
          <p class="text-white/50 text-sm mt-1">Bienvenido al panel de administración de Elevate Travel.</p>
        </div>
      </div>

      <!-- ✅ Stats con datos reales del BE -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div class="glass-panel p-6 rounded-xl flex items-center justify-between">
          <div>
            <p class="text-white/50 text-xs uppercase tracking-widest mb-1">Destinos</p>
            <h3 class="text-3xl font-light">{{ stats.destinations ?? '—' }}</h3>
          </div>
          <div class="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center text-white/70">
            <i class="pi pi-map-marker text-xl"></i>
          </div>
        </div>

        <div class="glass-panel p-6 rounded-xl flex items-center justify-between">
          <div>
            <p class="text-white/50 text-xs uppercase tracking-widest mb-1">Eventos</p>
            <h3 class="text-3xl font-light">{{ stats.events ?? '—' }}</h3>
          </div>
          <div class="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center text-white/70">
            <i class="pi pi-calendar text-xl"></i>
          </div>
        </div>

        <div class="glass-panel p-6 rounded-xl flex items-center justify-between">
          <div>
            <p class="text-white/50 text-xs uppercase tracking-widest mb-1">Paquetes</p>
            <h3 class="text-3xl font-light">{{ stats.packages ?? '—' }}</h3>
          </div>
          <div class="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center text-white/70">
            <i class="pi pi-briefcase text-xl"></i>
          </div>
        </div>

        <div class="glass-panel p-6 rounded-xl flex items-center justify-between">
          <div>
            <p class="text-white/50 text-xs uppercase tracking-widest mb-1">Ofertas Activas</p>
            <h3 class="text-3xl font-light">{{ stats.offers ?? '—' }}</h3>
          </div>
          <div class="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center text-white/70">
            <i class="pi pi-tags text-xl"></i>
          </div>
        </div>
      </div>

      <div class="glass-panel p-8 rounded-xl min-h-[400px] flex items-center justify-center text-center">
        <div class="max-w-md">
          <i class="pi pi-chart-line text-4xl text-white/20 mb-4 block"></i>
          <h2 class="text-xl font-light mb-2">Métricas en Desarrollo</h2>
          <p class="text-white/50 text-sm">El panel de analíticas avanzadas estará disponible próximamente.</p>
        </div>
      </div>
    </div>
  `
})
export class Dashboard implements OnInit {
  private destinationsService = inject(DestinationsService);
  private eventsService = inject(EventsService);
  private packagesService = inject(PackagesService);
  private offersService = inject(OffersService);

  stats: { destinations?: number; events?: number; packages?: number; offers?: number } = {};

  ngOnInit() {
    // ✅ Carga datos reales en lugar de números estáticos hardcodeados
    this.destinationsService.getAdminDestinations().subscribe({
      next: (data) => this.stats.destinations = data.length,
      error: () => {}
    });
    this.eventsService.getAdminEvents().subscribe({
      next: (data) => this.stats.events = data.length,
      error: () => {}
    });
    this.packagesService.getAdminPackages().subscribe({
      next: (data) => this.stats.packages = data.length,
      error: () => {}
    });
    this.offersService.getAdminOffers().subscribe({
      next: (data) => this.stats.offers = data.filter((o: any) => o.is_active).length,
      error: () => {}
    });
  }
}
