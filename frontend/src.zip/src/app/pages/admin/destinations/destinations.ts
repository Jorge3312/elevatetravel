import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators, FormsModule } from '@angular/forms';
import { DestinationsService } from '../../../core/services/destinations';
import { TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import { DialogModule } from 'primeng/dialog';
import { InputTextModule } from 'primeng/inputtext';
import { ToggleSwitchModule } from 'primeng/toggleswitch';

@Component({
  selector: 'app-destinations',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, TableModule, ButtonModule, DialogModule, InputTextModule, ToggleSwitchModule],
  template: `
    <div class="space-y-6">
      <div class="flex justify-between items-center">
        <div>
          <h1 class="text-2xl font-light tracking-widest uppercase">Destinos</h1>
          <p class="text-white/50 text-sm mt-1">Gestiona los países y ciudades disponibles.</p>
        </div>
        <button pButton icon="pi pi-plus" label="Nuevo Destino" class="p-button-outlined p-button-sm" (click)="showDialog()"></button>
      </div>

      <div class="glass-panel rounded-xl overflow-hidden">
        <p-table [value]="destinations" [paginator]="true" [rows]="10" responsiveLayout="scroll" styleClass="p-datatable-sm p-datatable-dark">
          <ng-template pTemplate="header">
            <tr>
              <th>Imagen</th>
              <th>País</th>
              <th>Ciudad</th>
              <th>Estado</th>
              <th class="text-right">Acciones</th>
            </tr>
          </ng-template>
          <ng-template pTemplate="body" let-dest>
            <tr>
              <td><img [src]="dest.photo_url" class="w-12 h-12 object-cover rounded-lg" alt="Destino"></td>
              <td class="font-medium">{{ dest.country }}</td>
              <td>{{ dest.city }}</td>
              <td>
                <p-toggleswitch [ngModel]="dest.is_active" (onChange)="toggleStatus(dest)"></p-toggleswitch>
              </td>
              <td class="text-right space-x-2">
                <button pButton icon="pi pi-pencil" class="p-button-rounded p-button-text p-button-sm" (click)="editDestination(dest)"></button>
                <button pButton icon="pi pi-trash" class="p-button-rounded p-button-text p-button-danger p-button-sm" (click)="deleteDestination(dest.id)"></button>
              </td>
            </tr>
          </ng-template>
        </p-table>
      </div>

      <p-dialog [(visible)]="displayDialog" [header]="isEditing ? 'Editar Destino' : 'Nuevo Destino'" [modal]="true" [style]="{width: '450px'}" styleClass="p-fluid">
        <form [formGroup]="form" (ngSubmit)="saveDestination()" class="space-y-4 mt-4">
          <div class="field">
            <label class="text-sm text-white/70 block mb-2">País</label>
            <input pInputText formControlName="country" class="w-full bg-black/50 border-white/10" />
          </div>
          <div class="field">
            <label class="text-sm text-white/70 block mb-2">Ciudad</label>
            <input pInputText formControlName="city" class="w-full bg-black/50 border-white/10" />
          </div>
          <div class="field">
            <label class="text-sm text-white/70 block mb-2">URL de Fotografía</label>
            <input pInputText formControlName="photo_url" class="w-full bg-black/50 border-white/10" />
          </div>
          <div class="field flex items-center justify-between pt-2">
            <label class="text-sm text-white/70">Activo</label>
            <p-toggleswitch formControlName="is_active"></p-toggleswitch>
          </div>
        </form>
        <ng-template pTemplate="footer">
          <button pButton label="Cancelar" icon="pi pi-times" class="p-button-text" (click)="displayDialog = false"></button>
          <button pButton label="Guardar" icon="pi pi-check" class="p-button-outlined" [disabled]="form.invalid" (click)="saveDestination()"></button>
        </ng-template>
      </p-dialog>
    </div>
  `,
  styles: [`
    ::ng-deep .p-datatable-dark .p-datatable-header,
    ::ng-deep .p-datatable-dark .p-datatable-thead > tr > th {
      background: rgba(0,0,0,0.5) !important;
      color: white !important;
      border-bottom: 1px solid rgba(255,255,255,0.1);
    }
    ::ng-deep .p-datatable-dark .p-datatable-tbody > tr > td {
      background: transparent !important;
      color: rgba(255,255,255,0.8);
      border-bottom: 1px solid rgba(255,255,255,0.05);
    }
    ::ng-deep .p-dialog {
      background: #111;
      border: 1px solid rgba(255,255,255,0.1);
    }
    ::ng-deep .p-dialog-header, ::ng-deep .p-dialog-content, ::ng-deep .p-dialog-footer {
      background: transparent !important;
      color: white;
    }
  `]
})
export class Destinations implements OnInit {
  private destinationsService = inject(DestinationsService);
  private fb = inject(FormBuilder);

  destinations: any[] = [];
  displayDialog = false;
  isEditing = false;
  currentId: string | null = null;

  form: FormGroup = this.fb.group({
    country: ['', Validators.required],
    city: ['', Validators.required],
    photo_url: ['', Validators.required],
    is_active: [true]
  });

  ngOnInit() {
    this.loadDestinations();
  }

  loadDestinations() {
    this.destinationsService.getAdminDestinations().subscribe({
      next: (data) => this.destinations = data,
      error: (err) => console.error('Error cargando destinos', err)
    });
  }

  showDialog() {
    this.isEditing = false;
    this.currentId = null;
    this.form.reset({ is_active: true });
    this.displayDialog = true;
  }

  editDestination(dest: any) {
    this.isEditing = true;
    this.currentId = dest.id;
    this.form.patchValue(dest);
    this.displayDialog = true;
  }

  saveDestination() {
    if (this.form.invalid) return;

    const req = this.isEditing && this.currentId
      ? this.destinationsService.update(this.currentId, this.form.value)
      : this.destinationsService.create(this.form.value);

    req.subscribe({
      next: () => {
        this.displayDialog = false;
        this.loadDestinations();
      },
      error: (err) => console.error('Error guardando', err)
    });
  }

  deleteDestination(id: string) {
    if (confirm('¿Estás seguro de eliminar este destino?')) {
      this.destinationsService.delete(id).subscribe({
        next: () => this.loadDestinations(),
        error: (err) => alert(err.error?.message || 'Error eliminando destino')
      });
    }
  }

  toggleStatus(dest: any) {
    this.destinationsService.toggleStatus(dest.id).subscribe({
      next: () => { dest.is_active = !dest.is_active; },
      error: (err) => console.error('Error cambiando estado', err)
    });
  }
}
