import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators, FormsModule } from '@angular/forms';
import { VisasService } from '../../../core/services/visas';
import { DestinationsService } from '../../../core/services/destinations';
import { TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import { DialogModule } from 'primeng/dialog';
import { InputTextModule } from 'primeng/inputtext';
import { ToggleSwitchModule } from 'primeng/toggleswitch';
import { SelectModule } from 'primeng/select';
import { QuillModule } from 'ngx-quill';

@Component({
  selector: 'app-visas',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, TableModule, ButtonModule, DialogModule, InputTextModule, ToggleSwitchModule, SelectModule, QuillModule],
  template: `
    <div class="space-y-6">
      <div class="flex justify-between items-center">
        <div>
          <h1 class="text-2xl font-light tracking-widest uppercase">Visas</h1>
          <p class="text-white/50 text-sm mt-1">Gestiona la información de visado por destino.</p>
        </div>
        <button pButton icon="pi pi-plus" label="Nueva Visa" class="p-button-outlined p-button-sm" (click)="showDialog()"></button>
      </div>

      <div class="glass-panel rounded-xl overflow-hidden">
        <p-table [value]="visas" [paginator]="true" [rows]="10" responsiveLayout="scroll" styleClass="p-datatable-sm p-datatable-dark">
          <ng-template pTemplate="header">
            <tr>
              <th>Destino</th>
              <th>Tipo de Visa</th>
              <th>Estado</th>
              <th class="text-right">Acciones</th>
            </tr>
          </ng-template>
          <ng-template pTemplate="body" let-visa>
            <tr>
              <td class="font-medium">{{ visa.destination?.city }}, {{ visa.destination?.country }}</td>
              <td>{{ visa.visa_type }}</td>
              <td>
                <p-toggleswitch [ngModel]="visa.is_active" (onChange)="toggleStatus(visa)"></p-toggleswitch>
              </td>
              <td class="text-right space-x-2">
                <button pButton icon="pi pi-pencil" class="p-button-rounded p-button-text p-button-sm" (click)="editVisa(visa)"></button>
                <button pButton icon="pi pi-trash" class="p-button-rounded p-button-text p-button-danger p-button-sm" (click)="deleteVisa(visa.id)"></button>
              </td>
            </tr>
          </ng-template>
        </p-table>
      </div>

      <p-dialog [(visible)]="displayDialog" [header]="isEditing ? 'Editar Visa' : 'Nueva Visa'" [modal]="true" [style]="{width: '700px'}" styleClass="p-fluid">
        <form [formGroup]="form" (ngSubmit)="saveVisa()" class="space-y-4 mt-4">
          <div class="grid grid-cols-2 gap-4">
            <div class="field">
              <label class="text-sm text-white/70 block mb-2">Destino</label>
              <p-select [options]="destinations" formControlName="destination_id" optionLabel="city" optionValue="id" placeholder="Seleccionar Destino" styleClass="w-full"></p-select>
            </div>
            <div class="field">
              <label class="text-sm text-white/70 block mb-2">Tipo de Visa</label>
              <input pInputText formControlName="visa_type" class="w-full bg-black/50 border-white/10" placeholder="Ej. Turista, Negocios" />
            </div>
          </div>

          <div class="field">
            <label class="text-sm text-white/70 block mb-2">Requisitos (Editor de Texto)</label>
            <div class="bg-white text-black rounded-lg overflow-hidden">
               <quill-editor formControlName="requirements" [styles]="{height: '250px'}"></quill-editor>
            </div>
          </div>

          <div class="field flex items-center justify-between pt-2">
            <label class="text-sm text-white/70">Activo</label>
            <p-toggleswitch formControlName="is_active"></p-toggleswitch>
          </div>
        </form>
        <ng-template pTemplate="footer">
          <button pButton label="Cancelar" icon="pi pi-times" class="p-button-text" (click)="displayDialog = false"></button>
          <button pButton label="Guardar" icon="pi pi-check" class="p-button-outlined" [disabled]="form.invalid" (click)="saveVisa()"></button>
        </ng-template>
      </p-dialog>
    </div>
  `
})
export class Visas implements OnInit {
  private visasService = inject(VisasService);
  private destService = inject(DestinationsService);
  private fb = inject(FormBuilder);

  visas: any[] = [];
  destinations: any[] = [];
  displayDialog = false;
  isEditing = false;
  currentId: string | null = null;

  form: FormGroup = this.fb.group({
    destination_id: ['', Validators.required],
    visa_type: ['', Validators.required],
    requirements: ['', Validators.required],
    is_active: [true]
  });

  ngOnInit() {
    this.loadVisas();
    this.destService.getAdminDestinations().subscribe(data => this.destinations = data);
  }

  loadVisas() {
    this.visasService.getAdminVisas().subscribe({
      next: (data) => this.visas = data,
      error: (err) => console.error(err)
    });
  }

  showDialog() {
    this.isEditing = false;
    this.currentId = null;
    this.form.reset({ is_active: true });
    this.displayDialog = true;
  }

  editVisa(visa: any) {
    this.isEditing = true;
    this.currentId = visa.id;
    this.form.patchValue({
      ...visa,
      destination_id: visa.destination?.id
    });
    this.displayDialog = true;
  }

  saveVisa() {
    if (this.form.invalid) return;
    const req = this.isEditing && this.currentId
      ? this.visasService.update(this.currentId, this.form.value)
      : this.visasService.create(this.form.value);

    req.subscribe({
      next: () => {
        this.displayDialog = false;
        this.loadVisas();
      },
      error: (err) => console.error(err)
    });
  }

  deleteVisa(id: string) {
    if (confirm('¿Eliminar visa?')) {
      this.visasService.delete(id).subscribe(() => this.loadVisas());
    }
  }

  toggleStatus(visa: any) {
    this.visasService.toggleStatus(visa.id).subscribe({
      next: () => visa.is_active = !visa.is_active,
      error: () => {}
    });
  }
}
