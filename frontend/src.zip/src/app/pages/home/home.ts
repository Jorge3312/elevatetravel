import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { DestinationsService } from '../../core/services/destinations';
import { PackagesService } from '../../core/services/packages';
import { EventsService } from '../../core/services/events';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule],
  template: `
    <!-- ═══════════════════════════════════════════
         HERO — imagen dinámica del primer destino
    ═══════════════════════════════════════════ -->
    <section class="relative h-screen w-full flex flex-col justify-end overflow-hidden">

      <!-- Fondo dinámico -->
      <div class="absolute inset-0">
        <img
          *ngIf="heroDestination?.photo_url; else heroBg"
          [src]="heroDestination.photo_url"
          [alt]="heroDestination.city"
          class="w-full h-full object-cover"
        />
        <ng-template #heroBg>
          <div class="w-full h-full bg-gradient-to-br from-zinc-900 via-zinc-800 to-black"></div>
        </ng-template>
        <!-- Degradados -->
        <div class="absolute inset-0 bg-gradient-to-r from-black/80 via-black/30 to-transparent"></div>
        <div class="absolute inset-0 bg-gradient-to-t from-[#0f0f0f] via-transparent to-black/40"></div>
      </div>

      <!-- Contenido hero -->
      <div class="relative z-10 px-8 md:px-16 pb-20 max-w-[1400px] mx-auto w-full">

        <!-- Etiqueta superior -->
        <div class="flex items-center gap-3 mb-6" *ngIf="heroDestination">
          <div class="h-px w-10 bg-amber-400"></div>
          <span class="text-xs tracking-[0.3em] uppercase text-amber-400 font-medium">
            {{ heroDestination.country }}
          </span>
        </div>

        <!-- Título grande -->
        <h1 class="font-display font-bold uppercase leading-[0.85] tracking-tighter text-white mb-8"
            style="font-size: clamp(4rem, 12vw, 11rem)">
          <ng-container *ngIf="heroDestination; else loadingHero">
            {{ heroDestination.city }}
          </ng-container>
          <ng-template #loadingHero>
            <span class="opacity-30">Cargando...</span>
          </ng-template>
        </h1>

        <!-- Stats rápidos -->
        <div class="flex flex-wrap gap-10 text-white/60 text-xs tracking-widest uppercase" *ngIf="destinations.length">
          <div>
            <span class="text-3xl font-light text-white block">{{ destinations.length }}</span>
            Destinos
          </div>
          <div>
            <span class="text-3xl font-light text-white block">{{ packages.length }}</span>
            Paquetes
          </div>
          <div>
            <span class="text-3xl font-light text-white block">{{ events.length }}</span>
            Eventos
          </div>
        </div>
      </div>

      <!-- Indicador scroll -->
      <div class="absolute bottom-8 right-10 z-10 flex flex-col items-center gap-2">
        <span class="text-[10px] tracking-widest uppercase text-white/30 rotate-90 mb-6">Scroll</span>
        <div class="w-px h-12 bg-white/20 relative overflow-hidden">
          <div class="w-full h-1/2 bg-amber-400 animate-bounce-slow absolute top-0"></div>
        </div>
      </div>

      <!-- Barra inferior amber -->
      <div class="absolute bottom-0 left-0 h-[2px] bg-gradient-to-r from-amber-400 to-transparent w-1/2 z-10"></div>
    </section>


    <!-- ═══════════════════════════════════════════
         DESTINOS
    ═══════════════════════════════════════════ -->
    <section id="destinations" class="py-24 bg-[#0f0f0f]">
      <div class="max-w-7xl mx-auto px-6 mb-14">
        <div class="flex items-end justify-between">
          <div>
            <p class="text-xs tracking-[0.3em] uppercase text-amber-400 mb-3">Explora el mundo</p>
            <h2 class="text-4xl md:text-5xl font-display font-bold uppercase tracking-tight">Destinos</h2>
          </div>
          <div class="hidden md:block h-px flex-1 mx-10 bg-white/10"></div>
        </div>
      </div>

      <!-- Loading -->
      <div *ngIf="loadingDest" class="max-w-7xl mx-auto px-6">
        <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div *ngFor="let s of [1,2,3,4]" class="h-80 bg-white/5 rounded-xl animate-pulse"></div>
        </div>
      </div>

      <!-- Grid destinos -->
      <div *ngIf="!loadingDest && destinations.length" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-0 md:gap-1">
        <div
          *ngFor="let dest of destinations.slice(0, 8)"
          class="relative h-80 md:h-[420px] overflow-hidden group cursor-pointer"
        >
          <img
            *ngIf="dest.photo_url"
            [src]="dest.photo_url"
            [alt]="dest.city"
            class="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
          />
          <div *ngIf="!dest.photo_url" class="w-full h-full bg-zinc-800"></div>

          <!-- Overlay -->
          <div class="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent opacity-80 group-hover:opacity-100 transition-opacity duration-500"></div>

          <!-- Info -->
          <div class="absolute bottom-0 left-0 p-6 w-full transform translate-y-2 group-hover:translate-y-0 transition-transform duration-500">
            <span class="text-[10px] tracking-widest uppercase text-amber-400 font-medium block mb-1">{{ dest.country }}</span>
            <h3 class="text-2xl font-display font-bold uppercase tracking-wide text-white">{{ dest.city }}</h3>
            <div class="flex items-center gap-2 mt-3 opacity-0 group-hover:opacity-100 transition-opacity duration-500 delay-100">
              <span class="text-xs text-white/60 tracking-widest uppercase">Ver paquetes</span>
              <i class="pi pi-arrow-right text-amber-400 text-xs"></i>
            </div>
          </div>
        </div>
      </div>

      <!-- Empty state -->
      <div *ngIf="!loadingDest && !destinations.length" class="max-w-7xl mx-auto px-6 text-center py-16 text-white/30">
        <i class="pi pi-map text-4xl mb-4 block"></i>
        <p class="tracking-widest uppercase text-sm">No hay destinos disponibles</p>
      </div>
    </section>


    <!-- ═══════════════════════════════════════════
         PAQUETES
    ═══════════════════════════════════════════ -->
    <section id="packages" class="py-24 bg-[#111111]">
      <div class="max-w-7xl mx-auto px-6 mb-14">
        <p class="text-xs tracking-[0.3em] uppercase text-amber-400 mb-3">Todo incluido</p>
        <h2 class="text-4xl md:text-5xl font-display font-bold uppercase tracking-tight">Paquetes</h2>
      </div>

      <!-- Loading -->
      <div *ngIf="loadingPkg" class="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-3 gap-6">
        <div *ngFor="let s of [1,2,3]" class="h-56 bg-white/5 rounded-xl animate-pulse"></div>
      </div>

      <!-- Cards paquetes -->
      <div *ngIf="!loadingPkg && packages.length" class="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div
          *ngFor="let pkg of packages"
          class="group relative border border-white/10 rounded-xl overflow-hidden bg-white/[0.03] hover:bg-white/[0.06] hover:border-white/20 transition-all duration-300"
        >
          <!-- Imagen si el destino tiene foto -->
          <div class="h-48 overflow-hidden relative" *ngIf="pkg.destination?.photo_url">
            <img
              [src]="pkg.destination.photo_url"
              [alt]="pkg.name"
              class="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 opacity-70"
            />
            <div class="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent"></div>
            <div class="absolute bottom-3 left-4 text-[10px] tracking-widest uppercase text-amber-400">
              {{ pkg.destination.city }}, {{ pkg.destination.country }}
            </div>
          </div>
          <div class="h-48 bg-zinc-900 flex items-center justify-center" *ngIf="!pkg.destination?.photo_url">
            <i class="pi pi-briefcase text-4xl text-white/10"></i>
          </div>

          <!-- Contenido -->
          <div class="p-6">
            <h3 class="text-lg font-display font-bold uppercase tracking-wider text-white mb-2">{{ pkg.name }}</h3>
            <p class="text-white/40 text-sm leading-relaxed mb-4 line-clamp-2">{{ pkg.description || 'Paquete de viaje exclusivo.' }}</p>

            <div class="flex items-center justify-between">
              <div class="flex items-center gap-4 text-white/50 text-xs">
                <span><i class="pi pi-sun mr-1 text-amber-400"></i>{{ pkg.days }}d / {{ pkg.nights }}n</span>
              </div>
              <div class="text-right">
                <span class="text-[10px] text-white/30 uppercase tracking-wider block">desde</span>
                <span class="text-xl font-light text-white">\${{ pkg.base_price | number:'1.0-0' }}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Empty state -->
      <div *ngIf="!loadingPkg && !packages.length" class="max-w-7xl mx-auto px-6 text-center py-16 text-white/30">
        <i class="pi pi-briefcase text-4xl mb-4 block"></i>
        <p class="tracking-widest uppercase text-sm">No hay paquetes disponibles</p>
      </div>
    </section>


    <!-- ═══════════════════════════════════════════
         EVENTOS
    ═══════════════════════════════════════════ -->
    <section id="events" class="py-24 bg-[#0f0f0f]">
      <div class="max-w-7xl mx-auto px-6 mb-14">
        <p class="text-xs tracking-[0.3em] uppercase text-amber-400 mb-3">Experiencias únicas</p>
        <h2 class="text-4xl md:text-5xl font-display font-bold uppercase tracking-tight">Eventos</h2>
      </div>

      <!-- Loading -->
      <div *ngIf="loadingEvt" class="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-2 gap-6">
        <div *ngFor="let s of [1,2]" class="h-44 bg-white/5 rounded-xl animate-pulse"></div>
      </div>

      <!-- Lista eventos -->
      <div *ngIf="!loadingEvt && events.length" class="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-2 gap-6">
        <div
          *ngFor="let evt of events"
          class="group flex gap-0 border border-white/10 rounded-xl overflow-hidden hover:border-amber-400/30 transition-all duration-300 bg-white/[0.02]"
        >
          <!-- Foto evento -->
          <div class="w-44 shrink-0 relative overflow-hidden" *ngIf="evt.photo_url">
            <img [src]="evt.photo_url" [alt]="evt.name" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 opacity-80" />
          </div>
          <div class="w-44 shrink-0 bg-zinc-900 flex items-center justify-center" *ngIf="!evt.photo_url">
            <i class="pi pi-calendar text-3xl text-white/10"></i>
          </div>

          <!-- Detalles -->
          <div class="p-5 flex flex-col justify-between flex-1">
            <div>
              <div class="flex items-center gap-2 mb-2">
                <i class="pi pi-map-marker text-amber-400 text-xs"></i>
                <span class="text-[10px] tracking-widest uppercase text-white/40">
                  {{ evt.destination?.city || 'Destino' }}
                </span>
              </div>
              <h3 class="font-display font-bold uppercase tracking-wide text-white text-base">{{ evt.name }}</h3>
              <p class="text-white/30 text-xs mt-1 line-clamp-2">{{ evt.description }}</p>
            </div>
            <div class="flex items-end justify-between mt-4">
              <div class="flex items-center gap-1 text-white/40 text-xs">
                <i class="pi pi-calendar text-amber-400"></i>
                <span>{{ evt.event_date | date:'MMM d, y' }}</span>
              </div>
              <span class="text-lg font-light text-white">\${{ evt.base_price | number:'1.0-0' }}</span>
            </div>
          </div>
        </div>
      </div>

      <!-- Empty state -->
      <div *ngIf="!loadingEvt && !events.length" class="max-w-7xl mx-auto px-6 text-center py-16 text-white/30">
        <i class="pi pi-calendar text-4xl mb-4 block"></i>
        <p class="tracking-widest uppercase text-sm">No hay eventos disponibles</p>
      </div>
    </section>


    <!-- ═══════════════════════════════════════════
         CTA FINAL
    ═══════════════════════════════════════════ -->
    <section id="visas" class="relative py-32 overflow-hidden bg-black">
      <div class="absolute inset-0 opacity-20"
           style="background-image: radial-gradient(ellipse at 20% 50%, rgba(251,191,36,0.3) 0%, transparent 60%), radial-gradient(ellipse at 80% 50%, rgba(251,191,36,0.15) 0%, transparent 60%)">
      </div>
      <div class="relative z-10 max-w-3xl mx-auto px-6 text-center">
        <p class="text-xs tracking-[0.4em] uppercase text-amber-400 mb-6">Planifica tu próxima aventura</p>
        <h2 class="text-5xl md:text-7xl font-display font-bold uppercase leading-[0.9] tracking-tighter mb-10">
          Viaja.<br/>Explora.<br/>Inspírate.
        </h2>
        <p class="text-white/40 text-sm leading-relaxed max-w-md mx-auto mb-12">
          Descubre experiencias diseñadas para los viajeros más exigentes, con atención al detalle en cada paso.
        </p>
        <a
          href="mailto:hello@elevatetravel.com"
          class="inline-flex items-center gap-3 border border-amber-400/50 text-amber-400 px-8 py-4 rounded-full text-xs tracking-widest uppercase hover:bg-amber-400 hover:text-black transition-all duration-300 font-medium"
        >
          <i class="pi pi-envelope"></i>
          Contáctanos
        </a>
      </div>
    </section>
  `,
  styles: [`
    @keyframes bounce-slow {
      0%, 100% { transform: translateY(0); }
      50% { transform: translateY(6px); }
    }
    .animate-bounce-slow { animation: bounce-slow 2s ease-in-out infinite; }
    .line-clamp-2 {
      display: -webkit-box;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
      overflow: hidden;
    }
  `]
})
export class Home implements OnInit {
  private destService = inject(DestinationsService);
  private pkgService = inject(PackagesService);
  private evtService = inject(EventsService);

  destinations: any[] = [];
  packages: any[] = [];
  events: any[] = [];
  heroDestination: any = null;

  loadingDest = true;
  loadingPkg = true;
  loadingEvt = true;

  ngOnInit() {
    this.destService.getPublicDestinations().subscribe({
      next: (data) => {
        this.destinations = data;
        this.heroDestination = data[0] ?? null;
        this.loadingDest = false;
      },
      error: () => { this.loadingDest = false; }
    });

    this.pkgService.getPublicPackages().subscribe({
      next: (data) => { this.packages = data; this.loadingPkg = false; },
      error: () => { this.loadingPkg = false; }
    });

    this.evtService.getPublicEvents().subscribe({
      next: (data) => { this.events = data; this.loadingEvt = false; },
      error: () => { this.loadingEvt = false; }
    });
  }
}
