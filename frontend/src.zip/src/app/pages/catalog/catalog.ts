import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DestinationsService } from '../../core/services/destinations';
import { EventsService } from '../../core/services/events';
import { PackagesService } from '../../core/services/packages';
import { DialogModule } from 'primeng/dialog';

@Component({
  selector: 'app-catalog',
  standalone: true,
  imports: [CommonModule, DialogModule],
  template: `
    <div class="pt-32 pb-20 px-6 max-w-7xl mx-auto">
      <div class="mb-16">
        <span class="text-white/50 text-xs tracking-[0.3em] uppercase mb-4 block">Experiencias</span>
        <h1 class="text-4xl md:text-6xl font-light tracking-tight">Catálogo de Viajes</h1>
        
        <div class="flex gap-4 mt-8">
          <button class="px-6 py-2 rounded-full text-sm uppercase tracking-widest border" [class.bg-white]="filter === 'all'" [class.text-black]="filter === 'all'" [class.border-white]="filter === 'all'" [class.border-white/20]="filter !== 'all'" [class.text-white/70]="filter !== 'all'" (click)="filter = 'all'">Todo</button>
          <button class="px-6 py-2 rounded-full text-sm uppercase tracking-widest border" [class.bg-white]="filter === 'events'" [class.text-black]="filter === 'events'" [class.border-white]="filter === 'events'" [class.border-white/20]="filter !== 'events'" [class.text-white/70]="filter !== 'events'" (click)="filter = 'events'">Eventos</button>
          <button class="px-6 py-2 rounded-full text-sm uppercase tracking-widest border" [class.bg-white]="filter === 'packages'" [class.text-black]="filter === 'packages'" [class.border-white]="filter === 'packages'" [class.border-white/20]="filter !== 'packages'" [class.text-white/70]="filter !== 'packages'" (click)="filter = 'packages'">Paquetes</button>
        </div>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        <!-- Events -->
        @if (filter === 'all' || filter === 'events') {
          @for (evt of events; track evt.id) {
            <div class="glass-panel rounded-2xl overflow-hidden cursor-pointer group" (click)="showDetails(evt, 'event')">
              <div class="h-64 relative overflow-hidden">
                <img [src]="evt.photo_url || 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?q=80&w=2070&auto=format&fit=crop'" class="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700">
                <div class="absolute top-4 left-4 bg-black/50 backdrop-blur-md px-3 py-1 rounded-full text-xs tracking-widest uppercase">Evento</div>
              </div>
              <div class="p-6">
                <p class="text-white/50 text-xs tracking-widest uppercase mb-2">{{ evt.destination?.city }}</p>
                <h3 class="text-xl font-light mb-4">{{ evt.name }}</h3>
                <div class="flex justify-between items-center text-sm">
                  <span class="text-white/70">{{ evt.event_date | date }}</span>
                  <span class="font-medium">{{ evt.base_price | currency }}</span>
                </div>
              </div>
            </div>
          }
        }

        <!-- Packages -->
        @if (filter === 'all' || filter === 'packages') {
          @for (pkg of packages; track pkg.id) {
            <div class="glass-panel rounded-2xl overflow-hidden cursor-pointer group" (click)="showDetails(pkg, 'package')">
              <div class="h-64 relative overflow-hidden bg-white/5 flex items-center justify-center">
                <i class="pi pi-briefcase text-6xl text-white/20 group-hover:scale-110 transition-transform duration-700"></i>
                <div class="absolute top-4 left-4 bg-white/20 backdrop-blur-md px-3 py-1 rounded-full text-xs tracking-widest uppercase">Paquete</div>
              </div>
              <div class="p-6">
                <p class="text-white/50 text-xs tracking-widest uppercase mb-2">{{ pkg.destination?.city }}</p>
                <h3 class="text-xl font-light mb-4">{{ pkg.name }}</h3>
                <div class="flex justify-between items-center text-sm">
                  <span class="text-white/70">{{ pkg.days }} Días / {{ pkg.nights }} Noches</span>
                  <span class="font-medium">{{ pkg.base_price | currency }}</span>
                </div>
              </div>
            </div>
          }
        }
      </div>
    </div>

    <!-- Details Modal -->
    <p-dialog [(visible)]="displayModal" [modal]="true" [style]="{width: '600px', background: '#111', border: '1px solid rgba(255,255,255,0.1)'}" styleClass="premium-dialog">
      @if (selectedItem) {
        <div class="mt-4">
          <span class="text-white/50 text-xs tracking-widest uppercase">{{ selectedType === 'event' ? 'Evento' : 'Paquete' }} en {{ selectedItem.destination?.city }}</span>
          <h2 class="text-3xl font-light mt-2 mb-6">{{ selectedItem.name }}</h2>
          <p class="text-white/80 font-light leading-relaxed mb-8">{{ selectedItem.description || 'Detalles exclusivos disponibles bajo consulta.' }}</p>
          
          <div class="grid grid-cols-2 gap-4 border-t border-white/10 pt-6">
            <div>
              <p class="text-white/50 text-xs tracking-widest uppercase mb-1">Precio Base</p>
              <p class="text-xl font-light">{{ selectedItem.base_price | currency }}</p>
            </div>
            <div class="text-right">
              <a href="https://wa.me/1234567890?text=Hola, estoy interesado en: {{ selectedItem.name }}" target="_blank" class="inline-block bg-white text-black px-6 py-3 rounded-full text-sm uppercase tracking-widest hover:bg-gray-200 transition-colors">
                Consultar
              </a>
            </div>
          </div>
        </div>
      }
    </p-dialog>
  `,
  styles: [`
    ::ng-deep .premium-dialog .p-dialog-header { background: transparent !important; color: white; }
    ::ng-deep .premium-dialog .p-dialog-content { background: transparent !important; color: white; }
  `]
})
export class Catalog implements OnInit {
  private eventsService = inject(EventsService);
  private packagesService = inject(PackagesService);

  events: any[] = [];
  packages: any[] = [];
  filter: 'all' | 'events' | 'packages' = 'all';

  displayModal = false;
  selectedItem: any = null;
  selectedType: 'event' | 'package' | null = null;

  ngOnInit() {
    this.eventsService.getPublicEvents().subscribe(data => this.events = data);
    this.packagesService.getPublicPackages().subscribe(data => this.packages = data);
  }

  showDetails(item: any, type: 'event' | 'package') {
    this.selectedItem = item;
    this.selectedType = type;
    this.displayModal = true;
  }
}
