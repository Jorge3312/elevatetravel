import { Component, inject } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../core/services/auth';
import { NgIf } from '@angular/common';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [ReactiveFormsModule],
  template: `
    <div class="min-h-screen bg-[#0a0a0a] flex items-center justify-center p-4 relative overflow-hidden">
      <!-- Background Effects -->
      <div class="absolute top-[-20%] left-[-10%] w-[50%] h-[50%] bg-blue-900/20 blur-[120px] rounded-full pointer-events-none"></div>
      <div class="absolute bottom-[-20%] right-[-10%] w-[50%] h-[50%] bg-purple-900/20 blur-[120px] rounded-full pointer-events-none"></div>

      <div class="glass-panel w-full max-w-md p-10 rounded-2xl relative z-10">
        <div class="text-center mb-10">
          <h1 class="text-3xl font-light tracking-widest uppercase mb-2">Elevate</h1>
          <p class="text-white/50 tracking-wider text-sm uppercase">Backoffice Access</p>
        </div>

        <form [formGroup]="loginForm" (ngSubmit)="onSubmit()" class="space-y-6">
          
          @if(error) {
            <div class="bg-red-500/10 border border-red-500/50 text-red-400 p-4 rounded-lg text-sm text-center">
              {{ error }}
            </div>
          }

          <div>
            <label class="block text-xs uppercase tracking-widest text-white/50 mb-2">Email</label>
            <input 
              type="email" 
              formControlName="email"
              class="w-full bg-black/50 border border-white/10 rounded-lg px-4 py-3 text-white placeholder-white/20 focus:outline-none focus:border-white/30 focus:ring-1 focus:ring-white/30 transition-all"
              placeholder="admin@elevatetravel.com"
            >
          </div>

          <div>
            <label class="block text-xs uppercase tracking-widest text-white/50 mb-2">Password</label>
            <input 
              type="password" 
              formControlName="password"
              class="w-full bg-black/50 border border-white/10 rounded-lg px-4 py-3 text-white placeholder-white/20 focus:outline-none focus:border-white/30 focus:ring-1 focus:ring-white/30 transition-all"
              placeholder="••••••••"
            >
          </div>

          <button 
            type="submit" 
            [disabled]="loginForm.invalid || loading"
            class="w-full bg-white text-black hover:bg-gray-200 disabled:opacity-50 disabled:cursor-not-allowed font-medium uppercase tracking-widest text-sm py-4 rounded-lg transition-colors mt-8"
          >
            {{ loading ? 'Authenticating...' : 'Sign In' }}
          </button>
        </form>
      </div>
    </div>
  `
})
export class Login {
  private fb = inject(FormBuilder);
  private authService = inject(AuthService);
  private router = inject(Router);

  loginForm = this.fb.group({
    email: ['', [Validators.required, Validators.email]],
    password: ['', Validators.required]
  });

  loading = false;
  error = '';

  onSubmit() {
    if (this.loginForm.invalid) return;

    this.loading = true;
    this.error = '';

    this.authService.login(this.loginForm.value).subscribe({
      next: () => {
        this.router.navigate(['/admin']);
      },
      error: (err) => {
        this.loading = false;
        this.error = 'Credenciales inválidas. Por favor intenta de nuevo.';
      }
    });
  }
}
