import { Component, HostListener } from '@angular/core';
import { RouterOutlet, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-main-layout',
  standalone: true,
  imports: [RouterOutlet, RouterLink, CommonModule],
  template: `
    <div class="min-h-screen bg-[#0f0f0f] text-white flex flex-col">

      <!-- Navbar -->
      <nav
        class="fixed top-0 left-0 w-full z-50 transition-all duration-500"
        [class.bg-black]="scrolled"
        [class.shadow-lg]="scrolled"
        [class.border-b]="scrolled"
        [class.border-white/10]="scrolled"
      >
        <div class="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">

          <!-- Logo -->
          <a routerLink="/" class="flex items-center gap-3 group">
            <span class="w-2 h-2 bg-amber-400 rounded-full group-hover:scale-150 transition-transform duration-300"></span>
            <span class="text-2xl font-light tracking-[0.25em] uppercase text-white">Elevate</span>
          </a>

          <!-- Links (desktop) -->
          <div class="hidden md:flex items-center gap-10">
            <a href="#destinations" class="nav-link text-xs tracking-widest uppercase text-white/60 hover:text-white transition-colors duration-200 relative group">
              Destinos
              <span class="absolute -bottom-1 left-0 w-0 h-px bg-amber-400 group-hover:w-full transition-all duration-300"></span>
            </a>
            <a href="#packages" class="nav-link text-xs tracking-widest uppercase text-white/60 hover:text-white transition-colors duration-200 relative group">
              Paquetes
              <span class="absolute -bottom-1 left-0 w-0 h-px bg-amber-400 group-hover:w-full transition-all duration-300"></span>
            </a>
            <a href="#events" class="nav-link text-xs tracking-widest uppercase text-white/60 hover:text-white transition-colors duration-200 relative group">
              Eventos
              <span class="absolute -bottom-1 left-0 w-0 h-px bg-amber-400 group-hover:w-full transition-all duration-300"></span>
            </a>
            <a href="#visas" class="nav-link text-xs tracking-widest uppercase text-white/60 hover:text-white transition-colors duration-200 relative group">
              Visas
              <span class="absolute -bottom-1 left-0 w-0 h-px bg-amber-400 group-hover:w-full transition-all duration-300"></span>
            </a>
          </div>

          <!-- Admin CTA -->
          <a
            routerLink="/login"
            class="hidden md:flex items-center gap-2 text-xs tracking-widest uppercase border border-white/20 px-5 py-2.5 rounded-full hover:bg-amber-400 hover:text-black hover:border-amber-400 transition-all duration-300 font-medium"
          >
            <i class="pi pi-lock text-xs"></i>
            Portal Admin
          </a>

          <!-- Mobile hamburger -->
          <button class="md:hidden text-white p-2" (click)="menuOpen = !menuOpen">
            <i class="pi text-xl" [class.pi-bars]="!menuOpen" [class.pi-times]="menuOpen"></i>
          </button>
        </div>

        <!-- Mobile menu -->
        <div
          class="md:hidden overflow-hidden transition-all duration-300 bg-black border-t border-white/10"
          [class.max-h-0]="!menuOpen"
          [class.max-h-96]="menuOpen"
        >
          <div class="px-6 py-6 flex flex-col gap-5">
            <a href="#destinations" class="text-xs tracking-widest uppercase text-white/70" (click)="menuOpen = false">Destinos</a>
            <a href="#packages" class="text-xs tracking-widest uppercase text-white/70" (click)="menuOpen = false">Paquetes</a>
            <a href="#events" class="text-xs tracking-widest uppercase text-white/70" (click)="menuOpen = false">Eventos</a>
            <a href="#visas" class="text-xs tracking-widest uppercase text-white/70" (click)="menuOpen = false">Visas</a>
            <a routerLink="/login" class="text-xs tracking-widest uppercase text-amber-400" (click)="menuOpen = false">Portal Admin</a>
          </div>
        </div>
      </nav>

      <!-- Content -->
      <main class="flex-1">
        <router-outlet></router-outlet>
      </main>

      <!-- WhatsApp flotante -->
      <a
        href="https://wa.me/1234567890"
        target="_blank"
        class="fixed bottom-8 right-8 w-14 h-14 bg-green-500 rounded-full flex items-center justify-center text-white shadow-[0_0_24px_rgba(34,197,94,0.4)] hover:scale-110 hover:shadow-[0_0_36px_rgba(34,197,94,0.6)] transition-all z-50"
      >
        <i class="pi pi-whatsapp text-2xl"></i>
      </a>

      <!-- Footer -->
      <footer class="bg-black border-t border-white/10 py-16">
        <div class="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-4 gap-12">
          <div class="md:col-span-2">
            <div class="flex items-center gap-3 mb-4">
              <span class="w-2 h-2 bg-amber-400 rounded-full"></span>
              <span class="text-2xl font-light tracking-[0.25em] uppercase">Elevate</span>
            </div>
            <p class="text-white/40 font-light max-w-xs leading-relaxed text-sm">
              Experiencias de viaje exclusivas, diseñadas para quienes exigen lo mejor del mundo.
            </p>
          </div>
          <div>
            <h4 class="text-xs font-semibold tracking-widest uppercase mb-5 text-white/80">Explorar</h4>
            <ul class="space-y-3 text-white/40 text-sm">
              <li><a href="#destinations" class="hover:text-white transition-colors">Destinos</a></li>
              <li><a href="#packages" class="hover:text-white transition-colors">Paquetes</a></li>
              <li><a href="#events" class="hover:text-white transition-colors">Eventos</a></li>
            </ul>
          </div>
          <div>
            <h4 class="text-xs font-semibold tracking-widest uppercase mb-5 text-white/80">Contacto</h4>
            <ul class="space-y-3 text-white/40 text-sm">
              <li>hello&#64;elevatetravel.com</li>
              <li>+1 234 567 890</li>
            </ul>
          </div>
        </div>
        <div class="max-w-7xl mx-auto px-6 mt-12 pt-8 border-t border-white/5 flex justify-between items-center text-white/20 text-xs tracking-widest uppercase">
          <span>&copy; 2026 Elevate Travel.</span>
          <span>All rights reserved.</span>
        </div>
      </footer>
    </div>
  `
})
export class MainLayout {
  scrolled = false;
  menuOpen = false;

  @HostListener('window:scroll')
  onScroll() {
    this.scrolled = window.scrollY > 60;
  }
}
